#!/usr/bin/env bash
# One-command launcher for the JP Stock local analysis backend.
#
# Usage:
#   ./start_backend.sh                # uses DEEPSEEK_API_KEY if exported
#   DEEPSEEK_API_KEY=sk-xxx ./start_backend.sh
#
# The key is read (in order) from: $DEEPSEEK_API_KEY, then ~/.deepseek_key,
# then engine/.env (DEEPSEEK_API_KEY=...). Without a key the server still runs;
# only the AI note is skipped.
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PORT="${1:-8092}"
KEY=""

if [[ -z "${DEEPSEEK_API_KEY:-}" && -f "$HOME/.deepseek_key" ]]; then
  KEY="$(tr -d '[:space:]' < "$HOME/.deepseek_key")"
fi
if [[ -z "$KEY" && -f "$HERE/.env" ]]; then
  KEY="$(grep -E '^DEEPSEEK_API_KEY=' "$HERE/.env" | head -1 | cut -d= -f2- | tr -d '[:space:]')"
fi

export DEEPSEEK_API_KEY="${DEEPSEEK_API_KEY:-$KEY}"

if [[ -z "${DEEPSEEK_API_KEY:-}" ]]; then
  echo "WARN: no DEEPSEEK_API_KEY found (AI note disabled)."
  echo "      export it, or put it in ~/.deepseek_key or $(basename "$HERE")/.env"
fi

cd "$HERE"
exec python3 server.py "$PORT"
